﻿namespace JdjDelta
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.picDisp = new System.Windows.Forms.PictureBox();
            this.pnProperty = new System.Windows.Forms.Panel();
            this.tmrDisp = new System.Windows.Forms.Timer(this.components);
            this.txtFile = new System.Windows.Forms.TextBox();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.btnDraw_Front = new System.Windows.Forms.Button();
            this.btnDraw_90_inverse = new System.Windows.Forms.Button();
            this.btnDraw_90 = new System.Windows.Forms.Button();
            this.btnDraw_120 = new System.Windows.Forms.Button();
            this.btnDraw_240 = new System.Windows.Forms.Button();
            this.btnDraw_Top = new System.Windows.Forms.Button();
            this.btnDraw_Bottom = new System.Windows.Forms.Button();
            this.btnDraw_Normal = new System.Windows.Forms.Button();
            this.chkUserControl = new System.Windows.Forms.CheckBox();
            this.rd5 = new System.Windows.Forms.RadioButton();
            this.rd15 = new System.Windows.Forms.RadioButton();
            this.btnChangePos = new System.Windows.Forms.Button();
            this.txtPos_Z = new System.Windows.Forms.TextBox();
            this.txtPos_Y = new System.Windows.Forms.TextBox();
            this.txtPos_X = new System.Windows.Forms.TextBox();
            this.label329 = new System.Windows.Forms.Label();
            this.chkMouseControl = new System.Windows.Forms.CheckBox();
            this.btnKinematicsCompile = new System.Windows.Forms.Button();
            this.txtInverseKinematics = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lbTestDh = new System.Windows.Forms.Label();
            this.btnCheckDH = new System.Windows.Forms.Button();
            this.label294 = new System.Windows.Forms.Label();
            this.txtKinematicsString = new System.Windows.Forms.TextBox();
            this.txtForwardKinematics = new System.Windows.Forms.TextBox();
            this.chkDh = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.picDisp)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // picDisp
            // 
            this.picDisp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picDisp.Location = new System.Drawing.Point(12, 35);
            this.picDisp.Name = "picDisp";
            this.picDisp.Size = new System.Drawing.Size(425, 350);
            this.picDisp.TabIndex = 116;
            this.picDisp.TabStop = false;
            // 
            // pnProperty
            // 
            this.pnProperty.Location = new System.Drawing.Point(443, 35);
            this.pnProperty.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnProperty.Name = "pnProperty";
            this.pnProperty.Size = new System.Drawing.Size(222, 220);
            this.pnProperty.TabIndex = 421;
            // 
            // tmrDisp
            // 
            this.tmrDisp.Interval = 30;
            this.tmrDisp.Tick += new System.EventHandler(this.tmrDisp_Tick);
            // 
            // txtFile
            // 
            this.txtFile.Location = new System.Drawing.Point(13, 505);
            this.txtFile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFile.Multiline = true;
            this.txtFile.Name = "txtFile";
            this.txtFile.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtFile.Size = new System.Drawing.Size(1112, 108);
            this.txtFile.TabIndex = 423;
            this.txtFile.WordWrap = false;
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(13, 393);
            this.txtMessage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtMessage.Size = new System.Drawing.Size(1112, 108);
            this.txtMessage.TabIndex = 422;
            // 
            // btnDraw_Front
            // 
            this.btnDraw_Front.Location = new System.Drawing.Point(444, 261);
            this.btnDraw_Front.Name = "btnDraw_Front";
            this.btnDraw_Front.Size = new System.Drawing.Size(54, 23);
            this.btnDraw_Front.TabIndex = 424;
            this.btnDraw_Front.Text = "Front";
            this.btnDraw_Front.UseVisualStyleBackColor = true;
            this.btnDraw_Front.Click += new System.EventHandler(this.btnDraw_Front_Click);
            // 
            // btnDraw_90_inverse
            // 
            this.btnDraw_90_inverse.Location = new System.Drawing.Point(500, 261);
            this.btnDraw_90_inverse.Name = "btnDraw_90_inverse";
            this.btnDraw_90_inverse.Size = new System.Drawing.Size(54, 23);
            this.btnDraw_90_inverse.TabIndex = 424;
            this.btnDraw_90_inverse.Text = "-90";
            this.btnDraw_90_inverse.UseVisualStyleBackColor = true;
            this.btnDraw_90_inverse.Click += new System.EventHandler(this.btnDraw_90_inverse_Click);
            // 
            // btnDraw_90
            // 
            this.btnDraw_90.Location = new System.Drawing.Point(556, 261);
            this.btnDraw_90.Name = "btnDraw_90";
            this.btnDraw_90.Size = new System.Drawing.Size(54, 23);
            this.btnDraw_90.TabIndex = 424;
            this.btnDraw_90.Text = "90";
            this.btnDraw_90.UseVisualStyleBackColor = true;
            this.btnDraw_90.Click += new System.EventHandler(this.btnDraw_90_Click);
            // 
            // btnDraw_120
            // 
            this.btnDraw_120.Location = new System.Drawing.Point(612, 261);
            this.btnDraw_120.Name = "btnDraw_120";
            this.btnDraw_120.Size = new System.Drawing.Size(54, 23);
            this.btnDraw_120.TabIndex = 424;
            this.btnDraw_120.Text = "120";
            this.btnDraw_120.UseVisualStyleBackColor = true;
            this.btnDraw_120.Click += new System.EventHandler(this.btnDraw_120_Click);
            // 
            // btnDraw_240
            // 
            this.btnDraw_240.Location = new System.Drawing.Point(444, 290);
            this.btnDraw_240.Name = "btnDraw_240";
            this.btnDraw_240.Size = new System.Drawing.Size(54, 23);
            this.btnDraw_240.TabIndex = 424;
            this.btnDraw_240.Text = "240";
            this.btnDraw_240.UseVisualStyleBackColor = true;
            this.btnDraw_240.Click += new System.EventHandler(this.btnDraw_240_Click);
            // 
            // btnDraw_Top
            // 
            this.btnDraw_Top.Location = new System.Drawing.Point(500, 290);
            this.btnDraw_Top.Name = "btnDraw_Top";
            this.btnDraw_Top.Size = new System.Drawing.Size(54, 23);
            this.btnDraw_Top.TabIndex = 424;
            this.btnDraw_Top.Text = "Top";
            this.btnDraw_Top.UseVisualStyleBackColor = true;
            this.btnDraw_Top.Click += new System.EventHandler(this.btnDraw_Top_Click);
            // 
            // btnDraw_Bottom
            // 
            this.btnDraw_Bottom.Location = new System.Drawing.Point(556, 290);
            this.btnDraw_Bottom.Name = "btnDraw_Bottom";
            this.btnDraw_Bottom.Size = new System.Drawing.Size(54, 23);
            this.btnDraw_Bottom.TabIndex = 424;
            this.btnDraw_Bottom.Text = "Bottom";
            this.btnDraw_Bottom.UseVisualStyleBackColor = true;
            this.btnDraw_Bottom.Click += new System.EventHandler(this.btnDraw_Bottom_Click);
            // 
            // btnDraw_Normal
            // 
            this.btnDraw_Normal.Location = new System.Drawing.Point(612, 290);
            this.btnDraw_Normal.Name = "btnDraw_Normal";
            this.btnDraw_Normal.Size = new System.Drawing.Size(54, 23);
            this.btnDraw_Normal.TabIndex = 424;
            this.btnDraw_Normal.Text = "Normal";
            this.btnDraw_Normal.UseVisualStyleBackColor = true;
            this.btnDraw_Normal.Click += new System.EventHandler(this.btnDraw_Normal_Click);
            // 
            // chkUserControl
            // 
            this.chkUserControl.AutoSize = true;
            this.chkUserControl.Location = new System.Drawing.Point(12, 12);
            this.chkUserControl.Name = "chkUserControl";
            this.chkUserControl.Size = new System.Drawing.Size(128, 16);
            this.chkUserControl.TabIndex = 425;
            this.chkUserControl.Text = "사용자 컨트롤 사용";
            this.chkUserControl.UseVisualStyleBackColor = true;
            this.chkUserControl.CheckedChanged += new System.EventHandler(this.chkUserControl_CheckedChanged);
            // 
            // rd5
            // 
            this.rd5.AutoSize = true;
            this.rd5.Checked = true;
            this.rd5.Location = new System.Drawing.Point(230, 11);
            this.rd5.Name = "rd5";
            this.rd5.Size = new System.Drawing.Size(90, 16);
            this.rd5.TabIndex = 426;
            this.rd5.TabStop = true;
            this.rd5.Text = "Model 5mm";
            this.rd5.UseVisualStyleBackColor = true;
            this.rd5.CheckedChanged += new System.EventHandler(this.rd5_CheckedChanged);
            // 
            // rd15
            // 
            this.rd15.AutoSize = true;
            this.rd15.Location = new System.Drawing.Point(347, 11);
            this.rd15.Name = "rd15";
            this.rd15.Size = new System.Drawing.Size(96, 16);
            this.rd15.TabIndex = 426;
            this.rd15.TabStop = true;
            this.rd15.Text = "Model 15mm";
            this.rd15.UseVisualStyleBackColor = true;
            this.rd15.CheckedChanged += new System.EventHandler(this.rd15_CheckedChanged);
            // 
            // btnChangePos
            // 
            this.btnChangePos.Location = new System.Drawing.Point(399, 235);
            this.btnChangePos.Name = "btnChangePos";
            this.btnChangePos.Size = new System.Drawing.Size(40, 23);
            this.btnChangePos.TabIndex = 460;
            this.btnChangePos.Text = "Go";
            this.btnChangePos.UseVisualStyleBackColor = true;
            this.btnChangePos.Click += new System.EventHandler(this.btnChangePos_Click);
            // 
            // txtPos_Z
            // 
            this.txtPos_Z.Location = new System.Drawing.Point(357, 236);
            this.txtPos_Z.Name = "txtPos_Z";
            this.txtPos_Z.Size = new System.Drawing.Size(41, 21);
            this.txtPos_Z.TabIndex = 457;
            this.txtPos_Z.Text = "0";
            // 
            // txtPos_Y
            // 
            this.txtPos_Y.Location = new System.Drawing.Point(314, 236);
            this.txtPos_Y.Name = "txtPos_Y";
            this.txtPos_Y.Size = new System.Drawing.Size(41, 21);
            this.txtPos_Y.TabIndex = 458;
            this.txtPos_Y.Text = "15";
            // 
            // txtPos_X
            // 
            this.txtPos_X.Location = new System.Drawing.Point(271, 236);
            this.txtPos_X.Name = "txtPos_X";
            this.txtPos_X.Size = new System.Drawing.Size(41, 21);
            this.txtPos_X.TabIndex = 459;
            this.txtPos_X.Text = "0";
            // 
            // label329
            // 
            this.label329.AutoSize = true;
            this.label329.Location = new System.Drawing.Point(228, 240);
            this.label329.Name = "label329";
            this.label329.Size = new System.Drawing.Size(37, 12);
            this.label329.TabIndex = 456;
            this.label329.Text = "X,Y,Z";
            // 
            // chkMouseControl
            // 
            this.chkMouseControl.AutoSize = true;
            this.chkMouseControl.Location = new System.Drawing.Point(463, 12);
            this.chkMouseControl.Name = "chkMouseControl";
            this.chkMouseControl.Size = new System.Drawing.Size(104, 16);
            this.chkMouseControl.TabIndex = 425;
            this.chkMouseControl.Text = "화면 직접 이동";
            this.chkMouseControl.UseVisualStyleBackColor = true;
            this.chkMouseControl.CheckedChanged += new System.EventHandler(this.chkMouseControl_CheckedChanged);
            // 
            // btnKinematicsCompile
            // 
            this.btnKinematicsCompile.Location = new System.Drawing.Point(765, 577);
            this.btnKinematicsCompile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnKinematicsCompile.Name = "btnKinematicsCompile";
            this.btnKinematicsCompile.Size = new System.Drawing.Size(130, 36);
            this.btnKinematicsCompile.TabIndex = 463;
            this.btnKinematicsCompile.Text = "Compile";
            this.btnKinematicsCompile.UseVisualStyleBackColor = true;
            this.btnKinematicsCompile.Click += new System.EventHandler(this.btnKinematicsCompile_Click);
            // 
            // txtInverseKinematics
            // 
            this.txtInverseKinematics.Location = new System.Drawing.Point(6, 6);
            this.txtInverseKinematics.Multiline = true;
            this.txtInverseKinematics.Name = "txtInverseKinematics";
            this.txtInverseKinematics.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtInverseKinematics.Size = new System.Drawing.Size(433, 225);
            this.txtInverseKinematics.TabIndex = 462;
            this.txtInverseKinematics.WordWrap = false;
            this.txtInverseKinematics.TextChanged += new System.EventHandler(this.txtInverseKinematics_TextChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(672, 35);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(453, 291);
            this.tabControl1.TabIndex = 464;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.chkDh);
            this.tabPage1.Controls.Add(this.lbTestDh);
            this.tabPage1.Controls.Add(this.btnCheckDH);
            this.tabPage1.Controls.Add(this.label294);
            this.tabPage1.Controls.Add(this.txtKinematicsString);
            this.tabPage1.Controls.Add(this.txtForwardKinematics);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(445, 265);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Forward";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.txtInverseKinematics);
            this.tabPage2.Controls.Add(this.btnChangePos);
            this.tabPage2.Controls.Add(this.label329);
            this.tabPage2.Controls.Add(this.txtPos_Z);
            this.tabPage2.Controls.Add(this.txtPos_X);
            this.tabPage2.Controls.Add(this.txtPos_Y);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(445, 265);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Inverse";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lbTestDh
            // 
            this.lbTestDh.AutoSize = true;
            this.lbTestDh.Location = new System.Drawing.Point(66, 238);
            this.lbTestDh.Name = "lbTestDh";
            this.lbTestDh.Size = new System.Drawing.Size(54, 12);
            this.lbTestDh.TabIndex = 474;
            this.lbTestDh.Text = "[x, y, z]";
            this.lbTestDh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnCheckDH
            // 
            this.btnCheckDH.Location = new System.Drawing.Point(318, 234);
            this.btnCheckDH.Name = "btnCheckDH";
            this.btnCheckDH.Size = new System.Drawing.Size(121, 25);
            this.btnCheckDH.TabIndex = 473;
            this.btnCheckDH.Text = "Move to point";
            this.btnCheckDH.UseVisualStyleBackColor = true;
            this.btnCheckDH.Click += new System.EventHandler(this.btnCheckDH_Click);
            // 
            // label294
            // 
            this.label294.AutoSize = true;
            this.label294.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label294.ForeColor = System.Drawing.Color.Red;
            this.label294.Location = new System.Drawing.Point(6, 238);
            this.label294.Name = "label294";
            this.label294.Size = new System.Drawing.Size(40, 12);
            this.label294.TabIndex = 462;
            this.label294.Text = "D-H :";
            this.label294.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtKinematicsString
            // 
            this.txtKinematicsString.Location = new System.Drawing.Point(223, 29);
            this.txtKinematicsString.Multiline = true;
            this.txtKinematicsString.Name = "txtKinematicsString";
            this.txtKinematicsString.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtKinematicsString.Size = new System.Drawing.Size(216, 203);
            this.txtKinematicsString.TabIndex = 461;
            this.txtKinematicsString.WordWrap = false;
            // 
            // txtForwardKinematics
            // 
            this.txtForwardKinematics.Location = new System.Drawing.Point(6, 29);
            this.txtForwardKinematics.Multiline = true;
            this.txtForwardKinematics.Name = "txtForwardKinematics";
            this.txtForwardKinematics.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtForwardKinematics.Size = new System.Drawing.Size(212, 203);
            this.txtForwardKinematics.TabIndex = 461;
            this.txtForwardKinematics.WordWrap = false;
            // 
            // chkDh
            // 
            this.chkDh.AutoSize = true;
            this.chkDh.Location = new System.Drawing.Point(6, 8);
            this.chkDh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkDh.Name = "chkDh";
            this.chkDh.Size = new System.Drawing.Size(116, 16);
            this.chkDh.TabIndex = 465;
            this.chkDh.Text = "Show DH Object";
            this.chkDh.UseVisualStyleBackColor = true;
            this.chkDh.CheckedChanged += new System.EventHandler(this.chkDh_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1136, 626);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnKinematicsCompile);
            this.Controls.Add(this.rd15);
            this.Controls.Add(this.rd5);
            this.Controls.Add(this.chkMouseControl);
            this.Controls.Add(this.chkUserControl);
            this.Controls.Add(this.btnDraw_240);
            this.Controls.Add(this.btnDraw_90);
            this.Controls.Add(this.btnDraw_120);
            this.Controls.Add(this.btnDraw_90_inverse);
            this.Controls.Add(this.btnDraw_Normal);
            this.Controls.Add(this.btnDraw_Bottom);
            this.Controls.Add(this.btnDraw_Top);
            this.Controls.Add(this.btnDraw_Front);
            this.Controls.Add(this.txtFile);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.pnProperty);
            this.Controls.Add(this.picDisp);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picDisp)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picDisp;
        private System.Windows.Forms.Panel pnProperty;
        private System.Windows.Forms.Timer tmrDisp;
        private System.Windows.Forms.TextBox txtFile;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Button btnDraw_Front;
        private System.Windows.Forms.Button btnDraw_90_inverse;
        private System.Windows.Forms.Button btnDraw_90;
        private System.Windows.Forms.Button btnDraw_120;
        private System.Windows.Forms.Button btnDraw_240;
        private System.Windows.Forms.Button btnDraw_Top;
        private System.Windows.Forms.Button btnDraw_Bottom;
        private System.Windows.Forms.Button btnDraw_Normal;
        private System.Windows.Forms.CheckBox chkUserControl;
        private System.Windows.Forms.RadioButton rd5;
        private System.Windows.Forms.RadioButton rd15;
        private System.Windows.Forms.Button btnChangePos;
        private System.Windows.Forms.TextBox txtPos_Z;
        private System.Windows.Forms.TextBox txtPos_Y;
        private System.Windows.Forms.TextBox txtPos_X;
        private System.Windows.Forms.Label label329;
        private System.Windows.Forms.CheckBox chkMouseControl;
        private System.Windows.Forms.Button btnKinematicsCompile;
        private System.Windows.Forms.TextBox txtInverseKinematics;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lbTestDh;
        private System.Windows.Forms.Button btnCheckDH;
        private System.Windows.Forms.Label label294;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtKinematicsString;
        private System.Windows.Forms.TextBox txtForwardKinematics;
        private System.Windows.Forms.CheckBox chkDh;
    }
}

